# Delete a User with JDBC PreparedStatement

## Files
- `Main.java` — deletes the row where `id = 2` and reports whether a row was deleted.
- `schema.sql` — creates/selects the database; the optional table example is commented out.

## Setup
1. Ensure MySQL Server is running.
2. Ensure `mydatabase` and the `users` table already exist.
3. In `Main.java`, replace `your_password` with your MySQL password and update `USERNAME` if needed.
4. Add the MySQL Connector/J JAR to the Java project's classpath.

## Compile and run (Windows Command Prompt)
```bat
javac -cp ".;mysql-connector-j-<version>.jar" Main.java
java -cp ".;mysql-connector-j-<version>.jar" Main
```
Replace `<version>` with the version in your downloaded JAR filename. On macOS/Linux, use `:` instead of `;` in the classpath.

Expected output when ID 2 exists:
```text
Row deleted successfully.
```
If ID 2 does not exist:
```text
No rows were deleted.
```

Note: This permanently deletes the matching row. Run against a test database if you need to preserve real data.
