CREATE DATABASE IF NOT EXISTS mydatabase;
USE mydatabase;

-- If you need a sample users table for testing, run:
-- CREATE TABLE IF NOT EXISTS users (
--     id INT PRIMARY KEY AUTO_INCREMENT,
--     name VARCHAR(100) NOT NULL,
--     email VARCHAR(255) NOT NULL
-- );
